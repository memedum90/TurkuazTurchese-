﻿README

This distribution contains the data used in our publication “Recognizing Stances in Online Debates” (ACL, 2009).


====================================================================

Citation Information 

When using this data set, the following citation should be used: 

@INPROCEEDINGS{SomasundaranWiebeAcl2009,
  author = {Somasundaran, Swapna and Wiebe, Janyce},
  title = {Recognizing Stances in Online Debates},
  booktitle = { Joint Conference of the 47th Annual Meeting of
	the ACL and the 4th International Joint Conference on Natural Language
	Processing of the AFNLP},
  year = {2009},
  pages = {226--234},
  address = {Suntec, Singapore},
  month = {August},
  publisher = {Association for Computational Linguistics},
  url = {http://www.aclweb.org/anthology/P/P09/P09-1026}
}


====================================================================

Data Format:

There are 5 directories in this distribution, one for each debate. 
Of these, four debates were used for testing in the paper. 
The iPhone_vs_Blackberry debate was a part of the development set. 
Please refer to the publication for further details. 


Each file within the directories is a debate post. 
Within each file, a line that starts with “#stance=” provides the label for the post (debate stance which the post supports). 
We have retained the original text from the debate website for the stance headings. 
These are intuitive in most cases.  For example, in the iPhone_vs_Blcakberry debate, the stance “Blackberry : The eternal classic.” maps to a pro-Blackberry stance and the stance “iPhone : The next revolution of Apple.” Maps to a pro-iPhone stance. 
Note that in the Firefox vs. Internet Explorer debate,  we have the following stance mapping:
“It has a cute logo ... oh and Extensions... err Add-Ons” => pro-Firefox
“There's more Browsers than the IE? Firefox is an Animal and the Opera isn't about the Internet” => pro-IE

