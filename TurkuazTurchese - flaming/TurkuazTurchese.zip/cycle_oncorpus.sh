#!/bin/bash

python TT_main.py --no-proc religion &
sleep 300
# python TT_main.py --no-proc church &
# sleep 300
# python TT_main.py --no-proc massacre &
# sleep 300
python TT_main.py --no-proc healthcare &
sleep 300
python TT_main.py --no-proc gaymarriage &
sleep 300
# python TT_main.py --no-proc euthanasia &
# sleep 300
python TT_main.py --no-proc abortion &
sleep 300
# python TT_main.py --no-proc jesus &
# sleep 300
python TT_main.py --no-proc creation &
sleep 300
python TT_main.py --no-proc guns &
# sleep 300
# python TT_main.py --no-proc legitimatedefence &

